import json
import logging
import os
import redis
import boto3


def lambda_handler(event, context):
    # TODO implement
    """Store session data in Redis."""

    r = redis.StrictRedis(
        host='clustercfg.redis-sbx-redis-cluster.icole6.use1.cache.amazonaws.com',
        port=6379,
        password='bN763nagjajymTtfPxKZB0KOi3aNYc34PEoJJ7tEeqsxcmrivYDVUGxdPSX3hxac6f6ycvLSl6zquEVSrS4bVLctub71lxWm6DnnaxM7vjGmgDNmQQhXqW8xNZvdlSJ7',
        ssl=True
    )
    
    #test the connection
    r.set('hello', 'world')
    value = r.get('hello')
    print(value)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
